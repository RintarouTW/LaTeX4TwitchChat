'use strict'

const defaultOptions = { 
	speechLang : "Disabled",
	showImageUserList : ""
}

export { defaultOptions }
